import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { 
  Card, 
  CardContent, 
  CardMedia, 
  Typography, 
  Grid, 
  Box, 
  Chip } from '@mui/material';

function App() {

  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axios.get('https://rickandmortyapi.com/api/character')
      .then(resposta => {
        setPosts(resposta.data.results);
      })
      .catch(erro => {
        console.error("Houve um erro ao carregar os posts!", erro);
      });
  }, []);

  return (
    <Box sx={{ backgroundColor: '#1C1C1C', minHeight: '100vh', padding: '20px' }}>
      <Typography variant="h3" align="center" color="white" >
        C-A-R-D
      </Typography>

      <Grid container spacing={4} justifyContent="center">
        {posts.map(post => (
          <Grid item key={post.id} xs={12} sm={6} md={4} lg={3}>
            <Card sx={{ backgroundColor: '#363636', color: 'white', borderRadius: '8px', width: '300px', height: '450px'}}>
              <CardMedia
                component="img"
                height="200"
                image={`https://rickandmortyapi.com/api/character/avatar/${post.id}.jpeg`}
                alt={post.name}
              />
              <CardContent>
                <Typography variant="h5" >
                  {post.name}
                </Typography>

                <Box display="flex" alignItems="center" mt={1}>
                  <Chip
                    label={post.status}
                    sx={{
                      backgroundColor: post.status === 'Alive' ? 'green' : post.status === 'Dead' ? 'red' : 'gray',
                      color: 'white',
                      fontWeight: 'bold',
                    }}
                  />
                </Box>

                <Typography variant="body2" color="#808080" mt={3}>
                  Origem:
                </Typography>
                <Typography variant="body1">{post.origin.name}</Typography>

                <Typography variant="body2" color="#808080" mt={3}>
                  Localização:
                </Typography>
                <Typography variant="body1">{post.location.name}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}

export default App;
